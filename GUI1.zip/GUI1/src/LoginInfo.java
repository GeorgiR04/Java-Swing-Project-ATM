import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class LoginInfo implements ActionListener {

    JFrame frame = new JFrame();
    JLabel label = new JLabel("Successfully logged in!");
    JButton continue1 = new JButton("Continue");


    LoginInfo() {

        label.setBounds(42, -8, 400, 50);
        label.setFont(new Font(null, Font.PLAIN, 16));

        continue1.addActionListener(this);
        continue1.setBounds(74, 48, 100, 20);

        frame.setLocation(600, 350);
        frame.add(continue1);
        frame.add(label);
        frame.setTitle("LoginInfo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(250, 110);
        frame.setLayout(null);
        frame.setVisible(true);


      
    }
    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        Continue1 continue11 = new Continue1();
        frame.dispose();

    }
}