import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Continue1 {

    JFrame frame = new JFrame();
    JButton buttonLogin = new JButton();
    JButton buttonBack = new JButton();


    JTextField textfield1 = new JTextField();
    JTextField textfield2 = new JTextField();
    JTextField textfield3 = new JTextField();
    JTextField textfield4 = new JTextField();
    JTextField textfield5 = new JTextField();


    public static void main(String[] args) {
        new Continue1();
    }
    Continue1(){

        textfield5.setText("DSK Bank ATM Machine");
        textfield5.setBounds(10, 10, 200, 40);
        textfield5.setEditable(false);

        textfield1.setText("Enter Card Number");
        textfield1.setBounds(10, 100, 130, 20);
        textfield1.setEditable(false);
        textfield2.setBounds(10, 130, 130, 20);

        textfield3.setText("Enter Card Code");
        textfield3.setBounds(10, 180, 130, 20);
        textfield3.setEditable(false);
        textfield4.setBounds(10, 210, 130, 20);

        buttonBack.setText("Back");
        buttonBack.setBounds(10, 285, 120, 20);

        buttonLogin.setText("Login");
        buttonLogin.setBounds(170, 285, 120, 20);


        buttonLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String CardNUM = textfield1.getText();
                String CardPIN = textfield3.getText();

                try{
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/CardInfo","root","");
                    PreparedStatement statement = con.prepareStatement("SELECT * FROM CardInfo Where CardNum = ? and CardPin = ?;");
//
                    statement.setLong(1, Long.parseLong(CardNUM));
                    statement.setLong(2, Integer.parseInt(CardPIN));

                    boolean isExist = statement.execute();

                    if(isExist){
                        System.out.println("Login");
                    }else{
                        System.out.println("No");
                    }
                    System.out.println("hi");
                    //    System.out.println("Card Number:" + rs.getLong(1));
                      //  System.out.println("Card Pin:" + rs.getLong(2));
                       // System.out.println("Card Owner:" + rs.getString(4));
                        //System.out.println("Card CVV:" + rs.getLong(3));
                      //  System.out.println("Card Creation Date:" + rs.getLong(5));
                        //System.out.println("Card Expiration Date:" + rs.getLong(6));
                        //System.out.println("");
                        //System.out.println("");
                    con.close();
                }catch(Exception e){
                    System.out.println(e);
                }
            }
        });

        buttonBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("ssss");
            }
        });


    frame.add(buttonLogin);
    frame.add(buttonBack);
    frame.add(textfield5);
    frame.add(textfield4);
    frame.add(textfield3);
    frame.add(textfield2);
    frame.add(textfield1);
    frame.setLocation(650, 1000);
    frame.setTitle("DSK Bank ATM Machine");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.getContentPane();
    frame.setSize(300,350);
    frame.setLayout(null);
    frame.setVisible(true);




    }

}

