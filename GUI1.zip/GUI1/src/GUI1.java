import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI1 {
    static double a=0,b=0,result=0;
    static int operator=0;
    private JTextField textField1;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JButton button6;
    private JButton button7;
    private JButton button8;
    private JButton button9;
    private JButton button10;
    private JButton button11;
    private JButton button12;
    private JPanel GUI12;
    private JButton button13;
    private JButton button14;
    private JButton clearButton;
    private JButton button15;
    private JButton button16;
    private JRadioButton radioButton1;

    public GUI1() {
        textField1.setEditable(false);


        button12.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("1");
                a=Double.parseDouble(textField1.getText());


            }
        });
        button11.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("2");
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });
        button10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("3");
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });
        button9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("5");
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });
        button8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("7");
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });
        button7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("0");
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });
        button6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("8");
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });
        button5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("6");
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("4");
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("9");
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("Icaka me nauchi kak da programiram na java");
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                textField1.setText("");

            }
        });
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                a=Double.parseDouble(textField1.getText());
                System.out.println(a);

            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Quiz");
        frame.setContentPane(new GUI1().GUI12);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(500, 500);
        frame.setResizable(false);
        frame.setVisible(true);



    }
}
