import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class LoginError implements ActionListener {

    JFrame frame = new JFrame();
    JLabel label = new JLabel("Logging unsuccessful! Try again.");
    JButton return1 = new JButton();
    private JPanel Erorr;

    LoginError(){

        label.setBounds(17,0,400,50);
        label.setFont(new Font(null,Font.PLAIN,14));

        return1.setBounds(70, 40, 100, 27);
        return1.setText("Retry");
        return1.addActionListener(this);
        frame.add(return1);
        frame.setLocation(650, 400);
        frame.add(label);
        frame.setTitle("LoginError");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane();
        frame.setSize(250,100);
        frame.setLayout(null);
        frame.setVisible(true);


        }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        frame.setVisible(false);


    }
}
