import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Connection1 {

    public static void main(String[] args) {
        try{

            Connection con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/CardInfo","root","");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT CardNum, CardPin, CardCVV, CardOwner, CardCreatDate, CardEXPDate FROM CardInfo");




            while(rs.next()) {
                System.out.println("Card Number:" + rs.getLong(1));
                System.out.println("Card Pin:" + rs.getLong(2));
                System.out.println("Card Owner:" + rs.getString(4));
                System.out.println("Card CVV:" + rs.getLong(3));
                System.out.println("Card Creation Date:" + rs.getLong(5));
                System.out.println("Card Expiration Date:" + rs.getLong(6));
                System.out.println("");
                System.out.println("");


            }
            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
}




