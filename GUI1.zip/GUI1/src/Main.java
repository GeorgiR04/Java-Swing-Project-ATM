import javax.swing.*;
import java.awt.event.ActionListener;


public class Main {

    public static void main(String[] args) {

        LoginPanel launchPage = new LoginPanel();

    }
}