
import java.awt.event.*;
import javax.swing.*;

public class LoginPanel implements ActionListener {

    JFrame frame = new JFrame();
    JButton myButton = new JButton("Login");
    JTextField textField1 = new JTextField();
    JTextField textField2 = new JTextField();
    JLabel jlabel1 = new JLabel();
    JLabel jlabel2 = new JLabel();


    LoginPanel() {

        myButton.setBounds(300, 325, 70, 30);
        myButton.setFocusable(false);
        myButton.addActionListener(this);

        textField1.setBounds(5, 120, 100, 30);
        textField2.setBounds(5, 240, 100, 30);

        jlabel1.setText("Username");
        jlabel1.setBounds(5, 100, 70, 15);
        jlabel2.setText("Password");
        jlabel2.setBounds(5, 220, 70, 15);

        frame.setLocation(500, 200);
        frame.add(jlabel2);
        frame.add(jlabel1);
        frame.add(textField1);
        frame.add(textField2);
        frame.add(myButton);
        frame.setTitle("Login Panel");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setLayout(null);
        frame.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String text = textField1.getText();
        String text1 = textField2.getText();


        if (text.equals("admin") && text1.equals("1234")) {
            frame.dispose();
            LoginInfo myWindow = new LoginInfo();

        } else {
            LoginError loginError = new LoginError();
        }
    }
}