import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class List implements ActionListener {
    JFrame frame = new JFrame();
    JTextField textField = new JTextField();




    List(){
        textField.setText("Ne znam brat");
        textField.setBounds(20, 20, 20, 20);

        frame.add(textField);
        frame.setLocation(650, 1000);
        frame.setTitle("Bank Account");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane();
        frame.setSize(300,350);
        frame.setLayout(null);
        frame.setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {

    }
}

